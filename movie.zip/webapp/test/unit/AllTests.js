sap.ui.define([
	"opensap/movie/test/unit/controller/App.controller"
], function () {
	"use strict";
});